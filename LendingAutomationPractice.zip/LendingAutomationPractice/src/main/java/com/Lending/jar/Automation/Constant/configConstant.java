package Lending.jar.Automation.Constant;

public class configConstant {

    //    Staging base Url
    public static String StagingBaseUri="https://dev.myjar.app/";

//    Edge stage Url
    public static String edgeStageUrl="https://dev-edge.myjar.app/";

    //    Prod-Replica  base Url
    public static String PRbaseUrl="https://prod-replica.myjar.app/";

    //    staging mongoDb url
    public static String mongoDbUrl_St="mongodb+srv://api_user:WQ6b3LhoemLey7hr@cluster0-pl-1.7kwfi.mongodb.net/?retryWrites=true&w=majority&readConcernLevel=majority";

//    DB_NAME
    public static String DB_NAME="Staging";

//    OTP_DB_NAME

    public static String OTP_DB_NAME="auth";

//    countryCode
    public static String countryCode="+91";

//    reqId
    public static String reqId="66850499e541f214269c8cb2";

//    collectionName
    public static String Otp_collectionName="smsDeliveryReports";

//    sortField
    public static String sortField="_id";

//    Json Schema basic url example
    public static String exampleUrl="https://jsonplaceholder.typicode.com";

}
