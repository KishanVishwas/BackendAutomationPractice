package Lending.jar.Automation.dataModel_I;

import lombok.Data;
import lombok.Getter;

import java.util.List;

@Data
public class excelMobilenumber
{
    public static List<String> mobileNumber;
}
