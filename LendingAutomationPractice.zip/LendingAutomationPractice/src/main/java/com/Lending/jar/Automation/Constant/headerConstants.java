package Lending.jar.Automation.Constant;

public class headerConstants {


    //    Header Content-Type
    public static final String contentType="application/json";

    //    AuthToken
    public static String authToken="eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiI2Njg1MmZmNzI0NGIyODIwYmFlM2E3YTAiLCJpYXQiOjE3MzEzMjg4NzUsImlzcyI6InN0YWdpbmciLCJleHAiOjE3MzEzMjk3NzUsImh0dHBzOi8vbXlqYXIuYXBwL2p3dC9jbGFpbXMiOnsidXNlcklkIjoiNjY4NTJmZjcyNDRiMjgyMGJhZTNhN2EwIiwicGhvbmVOdW1iZXIiOiIrOTE5NjExMDU1MzEyIiwicm9sZSI6IlVTRVIiLCJhcHBWZXJzaW9uIjoiMjEwIiwiZGV2aWNlSWQiOiIzNWZlZTZhZC02Zjg2LTRiMmMtOTBlZS00MWZjYzg0MDRhZTQiLCJpbXBlcnNvbmF0ZSI6ZmFsc2UsImFwcElkIjoiSkFSIiwic2lkIjoiNjczMWZiNmI3MTJmMWMxNzhkZTA4NDg5In19.iI3rYDAJUawC_zMIF91gGiKoeLoSjPTGLsOmkvgpb-YXeY1Brzjgv9bnqzrypZOpPNjFLpLIJ9MjpNL6PqNF_g";
//    base AuthToken
    public static String basicAuth="Basic cGFydG5lcl9pbmNlbnRpdmVfc2VydmljZTo1OWMyNTUxZmU0YmVmYjA4OTVlN2I3ZGI5NzMzNWRhMDRiMmI0NTlmZWViZWZlZWYxMGI5YTlkZDdlMjU3MmZi";

//    Mobile Number
    public static String mobileNumber="+916364298911";
    public static String phoneNumber="9611055312";

//    userId
    public static String userId="66852ff7244b2820bae3a7a0";

//    deviceId
    public static String deviceId="4174b56f6a931bfe";

//  advertisingId
    public static String advertisingId="35fee6ad-6f86-4b2c-90ee-41fcc8404ae4";

//    phoneModel
    public static String phoneModel="samsung SM-N971N";

//    appsFlyerId
    public static String appsFlyerId="1730975156019-8518020750726663309";

//    Age
    public static String age="25";

//    Credit Score
    public static String score="690";

//    totalAmountPastDue
    public static int totalAmountPastDue=50001;

//    totalCapsLast180Days
    public static int totalCapsLast180Days=17;

}
