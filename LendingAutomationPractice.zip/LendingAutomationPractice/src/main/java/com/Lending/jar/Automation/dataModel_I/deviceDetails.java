package Lending.jar.Automation.dataModel_I;

import lombok.Data;

@Data
public class deviceDetails
{
    private String userId;
    private String deviceId;
    private String advertisingId;
    private String appsFlyerId;
}


