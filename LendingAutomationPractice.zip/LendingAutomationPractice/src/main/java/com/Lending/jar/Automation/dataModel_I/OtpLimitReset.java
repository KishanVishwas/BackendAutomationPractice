package Lending.jar.Automation.dataModel_I;

import lombok.Data;

import java.util.Map;

@Data
public class OtpLimitReset
{
    private String mobileNumber;
}

