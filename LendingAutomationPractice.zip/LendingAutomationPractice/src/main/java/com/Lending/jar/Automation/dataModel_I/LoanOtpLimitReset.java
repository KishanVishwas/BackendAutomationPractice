package Lending.jar.Automation.dataModel_I;

import lombok.Data;

@Data
public class LoanOtpLimitReset {

    private String mobileNumber;

}
