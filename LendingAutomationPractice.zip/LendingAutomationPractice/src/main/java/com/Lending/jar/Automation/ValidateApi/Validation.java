package Lending.jar.Automation.ValidateApi;

import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

public class Validation
{
    public static void resetOtpvalidate(Response response)
    {
        String status = response.jsonPath().getString("success");
        Assert.assertEquals("true",status);
    }

    public static void resetValidate(Response response)
    {

        String success=response.jsonPath().getString("success");
        String data=response.jsonPath().getString("data");
        Assert.assertEquals("true",success);
        Assert.assertEquals("true",data);


    }

    public static void chatBot(Response response)
    {
        String status=response.jsonPath().getString("success");
        Assert.assertEquals("true",status);

    }

    public static void loanAgreement(Response response)
    {
        String status = response.jsonPath().getString("success");
        Assert.assertEquals("true",status);
    }

    public static void loginOtpValidate(Response response)
    {
        String status = response.jsonPath().getString("success");
        Assert.assertEquals("true",status);
    }
}
