package Lending.jar.Automation.Constant;


public class uriConstant {

//    need help chat bot
    public static String getAnswers="v2/api/loan/needHelp";

// resetOtp to reset the limit 1
    public static String resetOtp="v1/api/internal/auth/resetOtp";

//resetOtpVerifyLimit to reset the limit 2
    public static String resetOtpVerifyLimit="v1/api/internal/auth/resetOtpVerifyLimit";

//    Loan Otp reset
    public static String loanOtpreset="v1/api/internal/lending/resetOtp";

//    userDeviceDetails
    public static String userDeviceDetails="v2/api/user/device";

//    login Otp

    public static String loginOtp="v2/api/auth/requestOTP";

//    verify otp
    public static String verify_otp="v2/api/auth/verifyOTP";

//    Json Schema basic uri example
    public static String exampleUri="/users/1";

//    Json schema validation for rule engine Api
    public static String ruleEngine="rule-engine/v2/api/lending/ruleEngine/master/gating/checkEligibilityWebFlow";


}
